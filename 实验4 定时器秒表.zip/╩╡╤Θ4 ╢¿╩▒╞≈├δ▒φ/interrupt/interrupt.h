#ifndef _INTERRUPT_H
#define _INTERRUPT_H

#include"main.h"

void TIM_Init_Config(void);
void NVIC_InitConfig(void);

#endif
