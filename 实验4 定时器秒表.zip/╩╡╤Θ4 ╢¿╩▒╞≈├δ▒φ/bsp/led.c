#include"led.h"


void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}

extern uint8_t s;
//低电平驱动
const uint32_t led_Delay_ms = 100;
uint32_t LED_count = 0;
void Set_LED(uint16_t dsLED)
{
	if(LED_count <=0)
	{
		GPIO_Write(GPIOA, 0xFFFF);
		Delay_ms(led_Delay_ms);
	}
	else
		for(uint16_t i=0; i<8; i++)
		{
			GPIO_Write(GPIOA,_crol_(dsLED,i));
			Delay_ms(led_Delay_ms);
		}
	LED_count++;

}

void EXTI0_LED(void)
{
	for(int i=0; i<4; i++)
	{
		GPIO_Write(GPIOA, 0x00FF);
		delay_ms(led_Delay_ms);
		GPIO_Write(GPIOA, 0x0000);
		delay_ms(led_Delay_ms);
	}
}

void EXTI8_LED(void)
{
	for(int i=0; i<6; i++)
	{
		GPIO_Write(GPIOA, 0x00F0);
		delay_ms(led_Delay_ms);
		GPIO_Write(GPIOA, 0x000F);
		delay_ms(led_Delay_ms);
	}
}
