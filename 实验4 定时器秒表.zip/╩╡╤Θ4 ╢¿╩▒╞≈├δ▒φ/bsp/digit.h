#ifndef __DIGIT_H
#define __DIGIT_H

#include "main.h"

extern uint8_t hour;
extern uint8_t minute;
extern uint8_t second;
extern uint8_t display;

void digit_InitConfig(void);
void displayDigit(uint8_t digit);

#endif
