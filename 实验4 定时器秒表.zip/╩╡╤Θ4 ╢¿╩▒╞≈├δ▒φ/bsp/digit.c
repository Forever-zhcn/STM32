#include "digit.h"

//#define DigitOn(x) GPIO_WriteBit(GPIOA, 0x0001<<x, SET)// �򿪶�Ӧ�������
//#define DigitOff(x) GPIO_WriteBit(GPIOA, 0x0001<<x, RESET) // �رն�Ӧ�������
#define DigitOn(x) GPIOA->BSRR = (0x00000001<<x)// �򿪶�Ӧ�������
#define DigitOff(x) GPIOA->BSRR = (0x00010000<<x) // �رն�Ӧ�������

void digit_InitConfig(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = 0x003F;//���õ�6λ
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = 0x00FF;//���õ�8λ
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}


uint8_t hour = 0;
uint8_t minute = 0;
uint8_t second = 0;
uint8_t nums[10] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f};
uint8_t display = 0;

void displayDigit(uint8_t digit) 
{
    // �ر����������
    DigitOff(0);
    DigitOff(1);
    DigitOff(2);
    DigitOff(3);
		DigitOff(4);
    DigitOff(5);
    
   
    // �򿪶�Ӧ����ܣ�������
    switch (display) {
        case 0:
                DigitOn(0);
            break;
        case 1:
                DigitOn(1);
            break;
        case 2:
                DigitOn(2);
            break;
        case 3:
                DigitOn(3);
            break;
				case 4:
                DigitOn(4);
            break;
        case 5:
                DigitOn(5);
            break;
    }
		// ��ʾ��ǰ����
		//GPIO_Write(GPIOB, nums[digit]);
    GPIOB->ODR = nums[digit];
    

}

void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		
		second++;
		if(second>=60) 
		{
			second=0;
			minute++;
			if(minute>=60) 
			{
				minute=0;
				hour++;
				if(hour>=24) hour = 0;
			}
			
		}
		
		
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}
