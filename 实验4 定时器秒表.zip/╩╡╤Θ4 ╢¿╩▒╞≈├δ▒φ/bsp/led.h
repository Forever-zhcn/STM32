#ifndef _LED_H
#define _LED_H

#include"main.h"

void LED_Init(void);
void Set_LED(uint16_t dsLED);
void EXTI0_LED(void);
void EXTI8_LED(void);

#endif
