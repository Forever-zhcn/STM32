#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f10x.h"
#include "instrins.h" //左移右移函数头文件
#include "Delay.h" //延时函数头文件
#include "interrupt.h" //中断


#endif
