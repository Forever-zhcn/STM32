#include "main.h"
#include "digit.h"

int main(void)
{
	NVIC_InitConfig();
	TIM_Init_Config();
	
	digit_InitConfig();
	
	const static uint8_t digit_delay = 2;
	while(1)
	{
		 // �л������λ��
		display++;
		if (display > 5) display = 0;
		
		displayDigit(second / 10);
		Delay_ms(digit_delay);
		displayDigit(second % 10);
		Delay_ms(digit_delay);
		displayDigit(minute / 10);
		Delay_ms(digit_delay);
		displayDigit(minute % 10);
		Delay_ms(digit_delay);
		displayDigit(hour / 10);
		Delay_ms(digit_delay);
		displayDigit(hour % 10);
		Delay_ms(digit_delay);
		
	}
	
}



