#ifndef __DELAY_H
#define __DELAY_H

#include "main.h"

void delay_us(uint32_t delay_us);
void delay_ms(uint32_t delay_ms);


void Delay_us(uint32_t us);
void Delay_ms(uint32_t ms);
void Delay_s(uint32_t s);

#endif
