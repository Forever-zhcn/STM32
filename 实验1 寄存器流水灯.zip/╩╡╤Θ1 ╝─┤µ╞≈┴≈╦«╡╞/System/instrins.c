#include"instrins.h"

uint16_t _crol_(uint16_t GPIO_PIN,uint8_t x)
{
	GPIO_PIN = GPIO_PIN<<x | GPIO_PIN>>(16-x);
	return GPIO_PIN;
}

uint16_t _cror_(uint16_t GPIO_PIN,uint8_t x)
{
	GPIO_PIN = GPIO_PIN >> x | GPIO_PIN<<(16-x);
	return GPIO_PIN;
}
