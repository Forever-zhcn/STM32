#include"main.h"		

int main(void)
{
	//LED_Init();
	Key_Init();
	LED8_Init();
	
	while(1)
	{
		Set_LED8();
		//Get_LED();
	}
	
}



