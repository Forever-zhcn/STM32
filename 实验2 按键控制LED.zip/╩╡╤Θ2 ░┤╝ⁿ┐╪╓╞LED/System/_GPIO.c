#include"_GPIO.h"

/*
void Set_GPIO_Init(GPIO_TypeDef* GPIOx,uint16_t GPIO_PIN,GPIOSpeed_TypeDef GPIO_Speed,GPIOMode_TypeDef GPIO_Mode)

*GPIOx：选择GPIO端口，x:0~15。
*GPIO_PIN：选择引脚，GPIO_PIN可以是GPIO_PIN_0~GPIO_PIN_15、GPIO_PIN_All;
*GPIO_Speed：选择工作频率，可以是GPIO_Speed_10MHz、GPIO_Speed_50MHz、GPIO_Speed_2MHz。
*GPIO_Mode：	模拟输入：			GPIO_Mode_AIN
							浮空输入：			GPIO_Mode_IN_FLOATING
							下拉输入：			GPIO_Mode_IPD
							下拉输入：			GPIO_Mode_IPU
							开漏输出：			GPIO_Mode_Out_OD
							推挽输出：			GPIO_Mode_Out_PP
							复用开漏输出：	GPIO_Mode_AF_OD
							复用推挽输出：	GPIO_Mode_AF_PP
*/

void Set_GPIO_Output_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

//	if(GPIOx == GPIOA) RCC->APB2ENR = RCC->APB2ENR|0x00000004;
//	if(GPIOx == GPIOB) RCC->APB2ENR = RCC->APB2ENR|0x00000008;
//	if(GPIOx == GPIOC) RCC->APB2ENR = RCC->APB2ENR|0x00000010;
//	if(GPIOx == GPIOD) RCC->APB2ENR = RCC->APB2ENR|0x00000020;
//	if(GPIOx == GPIOE) RCC->APB2ENR = RCC->APB2ENR|0x00000040;
//	if(GPIOx == GPIOF) RCC->APB2ENR = RCC->APB2ENR|0x00000080;
//	if(GPIOx == GPIOG) RCC->APB2ENR = RCC->APB2ENR|0x00000100;
	

//	Set_GPIOx_Mode(GPIOx, GPIO_PIN, GPIO_Speed, GPIO_Mode);
//	Set_GPIO_Mode(GPIOx, GPIO_PIN, GPIO_Speed, GPIO_Mode);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode;
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed;
	GPIO_Init(GPIOx,&GPIO_InitStructure);
	
	
}

void Set_GPIO_Input_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode)
{
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
//	if(GPIOx == GPIOA) RCC->APB2ENR = RCC->APB2ENR|0x00000004;
//	if(GPIOx == GPIOB) RCC->APB2ENR = RCC->APB2ENR|0x00000008;
//	if(GPIOx == GPIOC) RCC->APB2ENR = RCC->APB2ENR|0x00000010;
//	if(GPIOx == GPIOD) RCC->APB2ENR = RCC->APB2ENR|0x00000020;
//	if(GPIOx == GPIOE) RCC->APB2ENR = RCC->APB2ENR|0x00000040;
//	if(GPIOx == GPIOF) RCC->APB2ENR = RCC->APB2ENR|0x00000080;
//	if(GPIOx == GPIOG) RCC->APB2ENR = RCC->APB2ENR|0x00000100;
	

//	Set_GPIOx_Mode(GPIOx, GPIO_PIN, GPIO_Speed, GPIO_Mode);
//	Set_GPIO_Mode(GPIOx, GPIO_PIN, GPIO_Speed, GPIO_Mode);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode;
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN;
	GPIO_Init(GPIOx,&GPIO_InitStructure);
	
	
}

void Set_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	Set_GPIO_Output_Init(GPIOx,GPIO_Pin,GPIO_Mode,GPIO_Speed);
	GPIOx->BSRR = GPIO_Pin;
	
}

void Set_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	Set_GPIO_Output_Init(GPIOx,0xFFFF,GPIO_Mode,GPIO_Speed);
}


void ReSet_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	Set_GPIO_Output_Init(GPIOx,GPIO_Pin,GPIO_Mode,GPIO_Speed);
	GPIOx->BSRR = GPIO_Pin<<16;
	
}

void ReSet_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	ReSet_GPIO_Bits(GPIOx,0xFFFF,GPIO_Mode,GPIO_Speed);
}




uint16_t Get_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode)
{
	Set_GPIO_Input_Init(GPIOx, GPIO_Pin, GPIO_Mode);
	GPIO_ReadInputDataBit(GPIOx, GPIO_Pin);
	return GPIO_ReadInputDataBit(GPIOx, GPIO_Pin);
}

uint16_t  Get_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode)
{
	Set_GPIO_Input_Init(GPIOx, GPIO_Pin_All, GPIO_Mode);
	GPIO_ReadInputData(GPIOx);
	return GPIO_ReadInputData(GPIOx);
}






void Set_GPIOx_Mode(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	if(GPIOx == GPIOA)
	{
		Set_GPIO_Mode(GPIOA, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOB)
	{
		Set_GPIO_Mode(GPIOB, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOC)
	{
		Set_GPIO_Mode(GPIOC, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOD)
	{
		Set_GPIO_Mode(GPIOD, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOE)
	{
		Set_GPIO_Mode(GPIOE, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOF)
	{
		Set_GPIO_Mode(GPIOF, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
	if(GPIOx == GPIOG)
	{
		Set_GPIO_Mode(GPIOG, GPIO_PIN, GPIO_Mode, GPIO_Speed);
	}
}

void Set_GPIO_Mode(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
	//模拟输入
		if(GPIO_Mode == GPIO_Mode_AIN)
		{
			if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X00000000;
			if(GPIO_PIN == GPIO_Pin_All)
			{
				GPIOx->CRL = 0X00000000;
				GPIOx->CRH = 0X00000000;
			}
		}
			
		
		//浮空输入
		if(GPIO_Mode == GPIO_Mode_IN_FLOATING)
		{
			if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000004;
			if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000040;
			if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000400;
			if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00004000;
			if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00040000;
			if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00400000;
			if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X04000000;
			if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X40000000;
			if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000004;
			if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000040;
			if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000400;
			if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00004000;
			if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00040000;
			if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00400000;
			if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X04000000;
			if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X40000000;
			if(GPIO_PIN == GPIO_Pin_All)
			{
				GPIOx->CRL = 0X44444444;
				GPIOx->CRH = 0X44444444;
			}
		}
		
		
		//上拉输入或下拉输入，还不完整
		if(GPIO_Mode == GPIO_Mode_IPD||GPIO_Mode == GPIO_Mode_IPU)
		{
			if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000008;
			if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000080;
			if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000800;
			if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00008000;
			if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00080000;
			if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00800000;
			if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X08000000;
			if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X80000000;
			if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000008;
			if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000080;
			if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000800;
			if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00008000;
			if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00080000;
			if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00800000;
			if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X08000000;
			if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X80000000;
			if(GPIO_PIN == GPIO_Pin_All)
			{
				GPIOx->CRL = 0X88888888;
				GPIOx->CRH = 0X88888888;
			}
		}
			
		
		
		//开漏输出
		if(GPIO_Mode == GPIO_Mode_Out_OD)
		{
			//1
			if(GPIO_Speed == GPIO_Speed_10MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000005;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000050;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000500;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00005000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00050000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00500000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X05000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X50000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000005;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000050;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000500;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00005000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00050000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00500000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X05000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X50000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X55555555;
					GPIOx->CRH = 0X55555555;
				}
			}
			
			//2
			if(GPIO_Speed == GPIO_Speed_2MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000006;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000060;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000600;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00006000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00060000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00600000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X06000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X60000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000006;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000060;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000600;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00006000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00060000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00600000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X06000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X60000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X66666666;
					GPIOx->CRH = 0X66666666;
				}
			}
			
			//3
			if(GPIO_Speed == GPIO_Speed_50MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000007;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000070;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000700;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00007000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00070000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00700000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X07000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X70000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000007;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000070;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000700;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00007000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00070000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00700000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X07000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X70000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X77777777;
					GPIOx->CRH = 0X77777777;
				}
			}
		}
		
		
		//推挽输出
		if(GPIO_Mode == GPIO_Mode_Out_PP)
		{
			//1
			if(GPIO_Speed == GPIO_Speed_10MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000001;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000010;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000100;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00001000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00010000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00100000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X01000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X10000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000001;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000010;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000100;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00001000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00010000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00100000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X01000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X10000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X11111111;
					GPIOx->CRH = 0X11111111;
				}
			}
			
			//2
			if(GPIO_Speed == GPIO_Speed_2MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000002;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000020;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000200;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00002000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00020000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00200000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X02000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X20000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000002;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000020;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000200;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00002000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00020000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00200000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X02000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X20000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X22222222;
					GPIOx->CRH = 0X22222222;
				}
			}
			
			//3
			if(GPIO_Speed == GPIO_Speed_50MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) 
					GPIOx->CRL = 0X00000003;
				if(GPIO_PIN == GPIO_Pin_1 ) 
					GPIOx->CRL = 0X00000030;
				if(GPIO_PIN == GPIO_Pin_2 )
					GPIOx->CRL = 0X00000300;
				if(GPIO_PIN == GPIO_Pin_3 ) 
					GPIOx->CRL = 0X00003000;
				if(GPIO_PIN == GPIO_Pin_4 ) 
					GPIOx->CRL = 0X00030000;
				if(GPIO_PIN == GPIO_Pin_5 ) 
					GPIOx->CRL = 0X00300000;
				if(GPIO_PIN == GPIO_Pin_6 )
					GPIOx->CRL = 0X03000000;
				if(GPIO_PIN == GPIO_Pin_7 ) 
					GPIOx->CRL = 0X30000000;
				if(GPIO_PIN == GPIO_Pin_8 )
					GPIOx->CRH = 0X00000003;
				if(GPIO_PIN == GPIO_Pin_9 ) 
					GPIOx->CRH = 0X00000030;
				if(GPIO_PIN == GPIO_Pin_10) 
					GPIOx->CRH = 0X00000300;
				if(GPIO_PIN == GPIO_Pin_11) 
					GPIOx->CRH = 0X00003000;
				if(GPIO_PIN == GPIO_Pin_12) 
					GPIOx->CRH = 0X00030000;
				if(GPIO_PIN == GPIO_Pin_13) 
					GPIOx->CRH = GPIOx->CRH|0X00300000;
				if(GPIO_PIN == GPIO_Pin_14) 
					GPIOx->CRH = 0X03000000;
				if(GPIO_PIN == GPIO_Pin_15) 
					GPIOx->CRH = 0X30000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X33333333;
					GPIOx->CRH = 0X33333333;
				}
			}
		}
		
		
		//复用开漏输出
		if(GPIO_Mode == GPIO_Mode_AF_OD)
		{
			//1
			if(GPIO_Speed == GPIO_Speed_10MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X0000000D;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X000000D0;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000D00;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X0000D000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X000D0000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00D00000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X0D000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0XD0000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X0000000D;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X000000D0;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000D00;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X0000D000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X000D0000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00D00000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X0D000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0XD0000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0XDDDDDDDD;
					GPIOx->CRH = 0XDDDDDDDD;
				}
			}
			
			//2
			if(GPIO_Speed == GPIO_Speed_2MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X0000000E;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X000000E0;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000E00;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X0000E000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X000E0000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00E00000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X0E000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0XE0000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X0000000E;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X000000E0;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000E00;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X0000E000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X000E0000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00E00000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X0E000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0XE0000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0XEEEEEEEE;
					GPIOx->CRH = 0XEEEEEEEE;
				}
			}
			
			//3
			if(GPIO_Speed == GPIO_Speed_50MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X0000000F;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X000000F0;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000F00;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X0000F000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X000F0000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00F00000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X0F000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0XF0000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X0000000F;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X000000F0;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000F00;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X0000F000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X000F0000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00F00000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X0F000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0XF0000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0XFFFFFFFF;
					GPIOx->CRH = 0XFFFFFFFF;
				}
			}
		}
		
		
		//复用推挽输出
		if(GPIO_Mode == GPIO_Mode_AF_PP)
		{
			//1
			if(GPIO_Speed == GPIO_Speed_10MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X00000009;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X00000090;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000900;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X00009000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X00090000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00900000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X09000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0X90000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X00000009;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X00000090;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000900;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X00009000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X00090000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00900000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X09000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0X90000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0X99999999;
					GPIOx->CRH = 0X99999999;
				}
			}
			
			//2
			if(GPIO_Speed == GPIO_Speed_2MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X0000000A;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X000000A0;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000A00;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X0000A000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X000A0000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00A00000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X0A000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0XA0000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X0000000A;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X000000A0;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000A00;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X0000A000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X000A0000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00A00000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X0A000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0XA0000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0XAAAAAAAA;
					GPIOx->CRH = 0XAAAAAAAA;
				}
			}
			
			//3
			if(GPIO_Speed == GPIO_Speed_50MHz)
			{
				if(GPIO_PIN == GPIO_Pin_0 ) GPIOx->CRL = 0X0000000B;
				if(GPIO_PIN == GPIO_Pin_1 ) GPIOx->CRL = 0X000000B0;
				if(GPIO_PIN == GPIO_Pin_2 ) GPIOx->CRL = 0X00000B00;
				if(GPIO_PIN == GPIO_Pin_3 ) GPIOx->CRL = 0X0000B000;
				if(GPIO_PIN == GPIO_Pin_4 ) GPIOx->CRL = 0X000B0000;
				if(GPIO_PIN == GPIO_Pin_5 ) GPIOx->CRL = 0X00B00000;
				if(GPIO_PIN == GPIO_Pin_6 ) GPIOx->CRL = 0X0B000000;
				if(GPIO_PIN == GPIO_Pin_7 ) GPIOx->CRL = 0XB0000000;
				if(GPIO_PIN == GPIO_Pin_8 ) GPIOx->CRH = 0X0000000B;
				if(GPIO_PIN == GPIO_Pin_9 ) GPIOx->CRH = 0X000000B0;
				if(GPIO_PIN == GPIO_Pin_10) GPIOx->CRH = 0X00000B00;
				if(GPIO_PIN == GPIO_Pin_11) GPIOx->CRH = 0X0000B000;
				if(GPIO_PIN == GPIO_Pin_12) GPIOx->CRH = 0X000B0000;
				if(GPIO_PIN == GPIO_Pin_13) GPIOx->CRH = 0X00B00000;
				if(GPIO_PIN == GPIO_Pin_14) GPIOx->CRH = 0X0B000000;
				if(GPIO_PIN == GPIO_Pin_15) GPIOx->CRH = 0XB0000000;
				if(GPIO_PIN == GPIO_Pin_All)
				{
					GPIOx->CRL = 0XBBBBBBBB;
					GPIOx->CRH = 0XBBBBBBBB;
				}
			}
		}
}

