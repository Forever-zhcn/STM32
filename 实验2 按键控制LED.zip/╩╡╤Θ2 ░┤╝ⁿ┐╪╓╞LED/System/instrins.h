#ifndef _INSTRINS_H
#define _INSTRINS_H

#include"main.h"

uint16_t _crol_(uint16_t GPIO_PIN,uint8_t x);
uint16_t _cror_(uint16_t GPIO_PIN,uint8_t x);

#endif
