#ifndef __GPIO_H
#define __GPIO_H

#include"main.h"

void Set_GPIO_Output_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
void Set_GPIO_Input_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode);
void Set_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
void ReSet_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
void Set_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
void ReSet_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
uint16_t Get_GPIO_Bits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode);
uint16_t  Get_GPIO(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef GPIO_Mode);

void Set_GPIOx_Mode(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);
void Set_GPIO_Mode(GPIO_TypeDef* GPIOx, uint16_t GPIO_PIN, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed);

#endif
