#ifndef _KEY_H
#define _KEY_H

#include"main.h"

void Key_Init(void);

#endif
