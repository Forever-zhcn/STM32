#include"led.h"


void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}

void LED8_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = 0x00FF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}


//低电平驱动
uint8_t key[2];
uint8_t key_Delay = 10;
void Get_LED(void)
{
	key[0] = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9);
	key[1] = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8);
	
	Delay_ms(key_Delay);
	
	if(key[0] == 1 && key[1] == 1)
	{
		GPIO_Write(GPIOA,0x0E);
	}
	
	if(key[0] == 1 && key[1] == 0)
	{
		GPIO_Write(GPIOA,0x0D);
	}
	
	if(key[0] == 0 && key[1]  == 1)
	{
		GPIO_Write(GPIOA,0x0B);
	}
	
	if(key[0] == 0 && key[1] == 0)
	{
		GPIO_Write(GPIOA,0x07);
	}
	
}

uint32_t LED8_Delay = 300;
uint8_t LED_0[17] ={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x00};
//uint8_t LED_1[10] ={};
void Set_LED8(void)
{
	for(uint16_t i=0; i<=9; i++)
	{
		GPIO_Write(GPIOA,LED_0[i]);
		Delay_ms(LED8_Delay);
	}
}

