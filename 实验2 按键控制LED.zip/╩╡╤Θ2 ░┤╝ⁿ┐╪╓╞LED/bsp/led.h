#ifndef _LED_H
#define _LED_H

#include"main.h"

void LED_Init(void);
void Get_LED(void);

void LED8_Init(void);
void Set_LED8(void);

#endif
